#include <iostream>
#include <string>
#include <map>

#define NOMINMAX
#include <Windows.h>

#include "json.hpp"
using json = nlohmann::json;