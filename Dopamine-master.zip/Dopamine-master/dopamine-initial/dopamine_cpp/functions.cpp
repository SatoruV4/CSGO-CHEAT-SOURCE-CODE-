#include "functions.h"
#include "set_clan_tag.h"

void functions::init()
{
	function_list["set_clan_tag"] = set_clan_tag;
}
