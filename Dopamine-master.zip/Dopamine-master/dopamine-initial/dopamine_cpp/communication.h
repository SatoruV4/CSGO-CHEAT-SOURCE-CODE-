#pragma once
#include "api.h"

namespace communication
{
	void init(std::string config);
}