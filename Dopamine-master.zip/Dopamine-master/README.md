  How to use
 
1st: Load the dopamine lua

2nd: Build the dll under the x86 architecture and as a Release in visual studio https://docs.microsoft.com/en-us/visualstudio/debugger/how-to-set-debug-and-release-configurations?view=vs-2019

3rd: Load the fatality.lua for the fatality clantag. The clantag luas are very easy to make so you should probably make your own
